
var $ = require('jquery');
alert();
window.$ = $;
$(function() {
  alert('it works!')

});

$(document).ready( function(){
  alert("ready");
});

// Responsive navigation*****************
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
        alert('responsive');
    } else {
        x.className = "topnav";
    }
}
